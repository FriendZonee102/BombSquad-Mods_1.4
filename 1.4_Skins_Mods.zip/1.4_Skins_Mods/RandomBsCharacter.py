# coding=utf-8
from bsSpaz import *

#create by Friends

# FriendsTesting ###################################
t = Appearance("Random Man")
t.colorTexture = "bombColor"
t.colorMaskTexture = "bombColorMask"
t.defaultColor = (2.3, 10.5, 10.8)
t.defaultHighlight = (1, 4, 5)
t.iconTexture = "cuteSpaz"
t.iconMaskTexture = "penguinIconMask"
t.headModel =     "bunnyPelvis"
t.torsoModel =    "agentHead"
t.pelvisModel =   "neoSpazPelvis"
t.upperArmModel = "neoSpazPelvis"
t.foreArmModel =  "neoSpazPelvis"
t.handModel =     "bunnyPelvis"
t.upperLegModel = "bunnyPelvis"
t.lowerLegModel = "aliLowerLeg"
t.toesModel =     "bunnyPelvis"
agentSounds =    ['freeze', 'explosion3,', 'explosion4', 'robot4']
agentHitSounds = ['splatter', 'splatter']
t.attackSounds = agentSounds
t.jumpSounds = agentSounds
t.impactSounds = agentHitSounds
t.deathSounds=["shatter"]
t.pickupSounds = agentSounds
t.fallSounds=["explosion01"]
t.style = 'bones'