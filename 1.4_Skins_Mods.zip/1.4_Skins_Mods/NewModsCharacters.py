# coding=utf-8
from bsSpaz import *

# Impact Spaz # Created by Friends
t = Appearance("Impact Spaz")
t.colorTexture = "impactBombColor"
t.colorMaskTexture = "impactBombColorMask"
t.iconTexture = "impactBombColor"
t.iconMaskTexture = "impactBombColor"

t.headModel = "neoSpazHead"
t.torsoModel = "neoSpazTorso"
t.pelvisModel = "neoSpazPelvis"
t.upperArmModel = "neoSpazUpperArm"
t.foreArmModel = "neoSpazForeArm"
t.handModel = "neoSpazHand"
t.upperLegModel = "neoSpazUpperLeg"
t.lowerLegModel = "neoSpazLowerLeg"
t.toesModel = "neoSpazToes"

t.jumpSounds=["spazJump01",
              "spazJump02",
              "spazJump03",
              "spazJump04"]
t.attackSounds=["spazAttack01",
                "spazAttack02",
                "spazAttack03",
                "spazAttack04"]
t.impactSounds=["spazImpact01",
                "spazImpact02",
                "spazImpact03",
                "spazImpact04"]
t.deathSounds=["spazDeath01"]
t.pickupSounds=["spazPickup01"]
t.fallSounds=["spazFall01"]

t.style = 'zoe'

# Easter B-9000 # Created by Friends
t = Appearance("Easter B-9000")
t.colorTexture = "bunnyColor"
t.colorMaskTexture = "bunnyColorMask"
t.iconTexture = "coin"
t.iconMaskTexture = "bunnyIconMask"

t.headModel = "bunnyHead"
t.torsoModel = "cyborgTorso"
t.pelvisModel = "cyborgPelvis"
t.upperArmModel = "cyborgUpperArm"
t.foreArmModel = "cyborgForeArm"
t.handModel = "cyborgHand"
t.upperLegModel = "cyborgUpperLeg"
t.lowerLegModel = "cyborgLowerLeg"
t.toesModel = "cyborgToes"

t.jumpSounds=["cyborgJump01",
              "cyborgJump02",
              "cyborgJump03",
              "cyborgJump04"]
t.attackSounds=["cyborgAttack01",
                "cyborgAttack02",
                "cyborgAttack03",
                "cyborgAttack04"]
t.impactSounds=["cyborgImpact01",
                "cyborgImpact02",
                "cyborgImpact03",
                "cyborgImpact04"]
t.deathSounds=["cyborgDeath01"]
t.pickupSounds=["cyborgPickup01"]
t.fallSounds=["cyborgFall01"]

t.style = 'bunny'

# Baby Bomb # Created by Friends
t = Appearance("Baby Bomb")
t.colorTexture = "bombColor"
t.colorMaskTexture = "bombColorMask"
t.iconTexture = "cuteSpaz"
t.iconMaskTexture = "cuteSpazColor"

t.headModel = "bunnyPelvis"
t.torsoModel = "bomb"
t.pelvisModel = "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel = "bunnyPelvis"
t.handModel = "bunnyPelvis"
t.upperLegModel = "bunnyPelvis"
t.lowerLegModel = "aliLowerLeg"
t.toesModel = "bunnyPelvis"
agentSounds =    ['freeze', 'explosion3,', 'explosion4', 'robot4']
agentHitSounds = ['splatter', 'splatter']
t.attackSounds = agentSounds
t.jumpSounds = agentSounds
t.impactSounds = agentHitSounds
t.deathSounds=["shatter"]
t.pickupSounds = agentSounds
t.fallSounds=["explosion01"]
t.style = 'bones'

# Eggy # Created by Friends
t = Appearance("Egg")
t.colorTexture = "egg1"
t.colorMaskTexture = "egg1"
t.iconTexture = "egg1"
t.iconMaskTexture = "egg1"

t.headModel = "bunnyPelvis"
t.torsoModel = "egg"
t.pelvisModel = "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel = "bunnyPelvis"
t.handModel = "bunnyPelvis"
t.upperLegModel = "bunnyPelvis"
t.lowerLegModel = "bunnyPelvis"
t.toesModel = "bunnyPelvis"

t.jumpSounds=["spazJump01",
              "spazJump02",
              "spazJump03",
              "spazJump04"]
t.attackSounds=["PunchStrong02",
                "PunchStrong02",
                "PunchStrong02",
                "PunchStrong02"]
t.impactSounds=["spazImpact01",
                "spazImpact02",
                "spazImpact03",
                "spazImpact04"]
t.deathSounds=["shatter"]
t.pickupSounds=["shatter"]
t.fallSounds=["shatter"]

t.style = 'spaz'