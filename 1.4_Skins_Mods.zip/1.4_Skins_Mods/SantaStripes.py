# coding=utf-8
from bsSpaz import *

# Penguin Dude # Created by Friends
t = Appearance("Santa Stripes")
t.colorTexture = "rgbStripes"
t.colorMaskTexture = "rgbStripes"
t.iconTexture = "santaIcon"
t.iconMaskTexture = "rgbStripes"

t.headModel = "santaHead"
t.torsoModel = "neoSpazTorso"
t.pelvisModel = "aliPelvis"
t.upperArmModel = "santaUpperArm"
t.foreArmModel = "santaForeArm"
t.handModel = "neoSpazHand"
t.upperLegModel = "santaUpperLeg"
t.lowerLegModel = "santaLowerLeg"
t.toesModel = "neoSpazToes"

t.jumpSounds=["penguinJump01",
              "penguinJump02",
              "penguinJump03",
              "penguinJump04"]
t.attackSounds=["penguinAttack01",
                "penguinAttack02",
                "penguinAttack03",
                "penguinAttack04"]
t.impactSounds=["pixieImpact01",
                "pixieImpact02",
                "pixieImpact03",
                "pixielmpact04"]
t.deathSounds=["cyborgDeath01"]
t.pickupSounds=["cyborgPickup01"]
t.fallSounds=["cyborgFall01"]

t.style = 'spaz'