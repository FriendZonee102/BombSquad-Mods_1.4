#coding=utf-8
from bsSpaz import *


t = Appearance("Baby Sticky")

t.colorTexture = "bombStickyColor"
t.colorMaskTexture = "impactBombColorMask"

t.defaultColor = (0.3,0.3,0.3)
#t.defaultHighlight = (0.2,0.8,0.8)

t.iconTexture = "cuteSpazIcon"
t.iconMaskTexture = "cuteSpazIconMask"

t.headModel =     "bunnyPelvis"
t.torsoModel =    "bombSticky"
t.pelvisModel =   "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel =  "bunnyPelvis"
t.handModel =     "bunnyPelvis"
t.upperLegModel = "bunnyPelvis"
t.lowerLegModel = "bunnyPelvis"
t.toesModel =     "bunnyPelvis"
t.attackSounds = ['powerdown01']
t.jumpSounds = ['powerup01']
t.impactSounds = ["powerdown01"]
t.deathSounds=['powerdown01']
t.pickupSounds = ['ticking']
t.fallSounds=["powerdown01"]

t.style = 'pixie'