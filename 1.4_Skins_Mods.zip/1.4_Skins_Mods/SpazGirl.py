# coding=utf-8
from bsSpaz import *

# Spaz 2.0 # Created by Friends
t = Appearance("Spaz Girl")
t.colorTexture = "kronkColor"
t.colorMaskTexture = "neoSpazColorMask"
t.iconTexture = "null"
t.iconMaskTexture = "neoSpazIconColorMask"

t.headModel = "zoeHead"
t.torsoModel = "zoeTorso"
t.pelvisModel = "neoSpazPelvis"
t.upperArmModel = "neoSpazUpperArm"
t.foreArmModel = "neoSpazForeArm"
t.handModel = "zoeHand"
t.upperLegModel = "neoSpazUpperLeg"
t.lowerLegModel = "neoSpazLowerLeg"
t.toesModel = "zoeToes"

t.jumpSounds=["zoeJump01",
              "spazJump02",
              "spazJump03",
              "spazJump04"]
t.attackSounds=["zoeAttack01",
                "spazAttack02",
                "spazAttack03",
                "spazAttack04"]
t.impactSounds=["zoeImpact01",
                "spazImpact02",
                "spazImpact03",
                "spazImpact04"]
t.deathSounds=["zoeDeath01"]
t.pickupSounds=["spazPickup01"]
t.fallSounds=["zoeFall01"]

t.style = 'spaz'