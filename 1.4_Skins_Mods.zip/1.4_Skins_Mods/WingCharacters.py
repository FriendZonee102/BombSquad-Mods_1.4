# coding=utf-8
from bsSpaz import *

# StigmaTesting ###################################
t = Appearance("Wing")
t.colorTexture = "agentColor"
t.colorMaskTexture = "agentColorMask"
t.defaultColor = (2.3, 10.5, 10.8)
t.defaultHighlight = (1, 4, 5)
t.iconTexture = "coin"
t.iconMaskTexture = "circleOutlineNoAlpha"
t.headModel =     "wing"
t.torsoModel =    "wing"
t.pelvisModel =   "wing"
t.upperArmModel = "wing"
t.foreArmModel =  "wing"
t.handModel =     "wing"
t.upperLegModel = "wing"
t.lowerLegModel = "wing"
t.toesModel =     "wing"
robotSounds =    ['robot1', 'robot2', 'robot3', 'robot4']
robotHitSounds = ['splatter', 'splatter']
t.attackSounds = robotSounds
t.jumpSounds = robotSounds
t.impactSounds = robotHitSounds
t.deathSounds=["shatter"]
t.pickupSounds = robotSounds
t.fallSounds=["shatter"]
t.style = 'spaz'