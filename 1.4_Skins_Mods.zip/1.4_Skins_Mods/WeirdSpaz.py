#coding=utf-8
from bsSpaz import *


t = Appearance("Weird Spaz")

t.colorTexture = "spazColor"
t.colorMaskTexture = "spazColorMask"

t.defaultColor = (0.3,0.3,0.3)
#t.defaultHighlight = (0.2,0.8,0.8)

t.iconTexture = "spaz"
t.iconMaskTexture = "pixieIconMask"

t.headModel =     "bunnyPelvis"
t.torsoModel =    "neoSpazTorso"
t.pelvisModel =   "bunnyPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel =  "bunnyPelvis"
t.handModel =     "bunnyPelvis"
t.upperLegModel = "bunnyPelvis"
t.lowerLegModel = "bunnyPelvis"
t.toesModel =     "neoSpazToes"
t.attackSounds = ['powerdown01']
t.jumpSounds = ['powerup01']
t.impactSounds = ["powerdown01"]
t.deathSounds=['powerdown01']
t.pickupSounds = ['shatter']
t.fallSounds=["powerdown01"]

t.style = 'pixie'