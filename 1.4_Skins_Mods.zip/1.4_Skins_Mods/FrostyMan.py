# coding=utf-8
from bsSpaz import *

# Penguin Dude # Created by Friends
t = Appearance("Frosty Man")
t.colorTexture = "cyborgColor"
t.colorMaskTexture = "egg2"
t.iconTexture = "frostyIcon"
t.iconMaskTexture = "eggTex1"

t.headModel = "frostyHead"
t.torsoModel = "cyborgTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "frostyUpperArm"
t.foreArmModel = "frostyForeArm"
t.handModel = "neoSpazHand"
t.upperLegModel = "frostyUpperLeg"
t.lowerLegModel = "frostyLowerLeg"
t.toesModel = "neoSpazToes"

t.jumpSounds=["frostyJump01",
              "frostyJump02",
              "frostyJump03",
              "frostyJump04"]
t.attackSounds=["frostyAttack01",
                "frostyAttack02",
                "frostyAttack03",
                "frostyAttack04"]
t.impactSounds=["pixieImpact01",
                "pixieImpact02",
                "pixieImpact03",
                "pixielmpact04"]
t.deathSounds=["frostyDeath01"]
t.pickupSounds=["shatter"]
t.fallSounds=["frostyFall01"]

t.style = 'female'