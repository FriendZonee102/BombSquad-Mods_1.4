# coding=utf-8
from bsSpaz import *

# Agent Mascot # Created by Friends
t = Appearance("Agent Mascot")
t.colorTexture = "agentColor"
t.colorMaskTexture = "pixieColorMask"
t.iconTexture = "aliIcon"
t.iconMaskTexture = "cuteSpazColorMask"

t.headModel = "aliHead"
t.torsoModel = "aliTorso"
t.pelvisModel = "aliPelvis"
t.upperArmModel = "agentUpperArm"
t.foreArmModel = "agentForeArm"
t.handModel = "agentHand"
t.upperLegModel = "aliUpperLeg"
t.lowerLegModel = "aliLowerLeg"
t.toesModel = "agentToes"

t.jumpSounds=["penguinJump01",
              "penguinJump02",
              "penguinJump03",
              "penguinJump04"]
t.attackSounds=["aliAttack01",
                "aliAttack02",
                "aliAttack03",
                "aliAttack04"]
t.impactSounds=["agentImpact01",
                "agentImpact02",
                "agentImpact03",
                "agentlmpact04"]
t.deathSounds=["agentDeath01"]
t.pickupSounds=["spazPickup01"]
t.fallSounds=["aliFall01"]

t.style = 'pixie'