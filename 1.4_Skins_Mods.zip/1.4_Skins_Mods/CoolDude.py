# coding=utf-8
from bsSpaz import *

# Friendly # Created by Friends
t = Appearance("Friendly")
t.colorTexture = "agentColor"
t.colorMaskTexture = "cuteSpazColorMask"
t.iconTexture = "chestIcon"
t.iconMaskTexture = "chestIcon"

t.headModel = "agentHead"
t.torsoModel = "bunnyTorso"
t.pelvisModel = "pixiePelvis"
t.upperArmModel = "cyborgUpperArm"
t.foreArmModel = "cyborgForeArm"
t.handModel = "bunnyPelvis"
t.upperLegModel = "cyborgUpperLeg"
t.lowerLegModel = "cyborgLowerLeg"
t.toesModel = "agentToes"

t.jumpSounds=["agentJump01",
              "agentJump02",
              "agentJump03",
              "agentJump04"]
t.attackSounds=["agentAttack01",
                "agentAttack02",
                "agentAttack03",
                "agentAttack04"]
t.impactSounds=["agentImpact01",
                "agentImpact02",
                "agentImpact03",
                "agentImpact04"]
t.deathSounds=["agentDeath01"]
t.pickupSounds=["agentPickup01"]
t.fallSounds=["agentFall01"]

t.style = 'agent'

# Samuari # Created by Friends
t = Appearance("Samuari")
t.colorTexture = "ninjaColor"
t.colorMaskTexture = "penguinColorMask"
t.iconTexture = "penguinIcon"
t.iconMaskTexture = "penguinIconColorMask"

t.headModel = "penguinHead"
t.torsoModel = "ninjaTorso"
t.pelvisModel = "ninjaPelvis"
t.upperArmModel = "ninjaUpperArm"
t.foreArmModel = "ninjaForeArm"
t.handModel = "ninjaHand"
t.upperLegModel = "ninjaUpperLeg"
t.lowerLegModel = "ninjaLowerLeg"
t.toesModel = "ninjaToes"

t.jumpSounds=["penguinJump01",
              "penguinJump02",
              "penguinJump03",
              "penguinJump04"]
t.attackSounds=["penguinAttack01",
                "penguinAttack02",
                "penguinAttack03",
                "penguinAttack04"]
t.impactSounds=["penguinImpact01",
                "penguinImpact02",
                "penguinImpact03",
                "penguinImpact04"]
t.deathSounds=["penguinDeath01"]
t.pickupSounds=["penguinPickup01"]
t.fallSounds=["penguinFall01"]

t.style = 'penguin'
