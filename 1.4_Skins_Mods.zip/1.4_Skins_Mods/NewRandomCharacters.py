# coding=utf-8
from bsSpaz import *

# Party Man # Created by Friends
t = Appearance("Party Man")
t.colorTexture = "spazColor"
t.colorMaskTexture = "egg1"
t.iconTexture = "egg1"
t.iconMaskTexture = "cyborgIconColorMask"

t.headModel = "cyborgHead"
t.torsoModel = "neoSpazTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "agentUpperArm"
t.foreArmModel = "agentForeArm"
t.handModel = "penguinHand"
t.upperLegModel = "cyborgUpperLeg"
t.lowerLegModel = "cyborgLowerLeg"
t.toesModel = "penguinToes"

t.jumpSounds=["cyborgJump01",
              "cyborgJump02",
              "cyborgJump03",
              "cyborgJump04"]
t.attackSounds=["agentAttack01",
                "agentAttack02",
                "agentAttack03",
                "agentAttack04"]
t.impactSounds=["pixieImpact01",
                "pixieImpact02",
                "pixieImpact03",
                "pixielmpact04"]
t.deathSounds=["cyborgDeath01"]
t.pickupSounds=["cyborgPickup01"]
t.fallSounds=["cyborgFall01"]

t.style = 'pixie'

# LandMine Health # Created by Friends
t = Appearance("LandMine Health")
t.colorTexture = "powerupHealth"
t.colorMaskTexture = "powerupHealth"
t.iconTexture = "powerupHealth"
t.iconMaskTexture = "powerupHealth"

t.headModel = "landMine"
t.torsoModel = "agentTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "aliUpperArm"
t.foreArmModel = "agentForeArm"
t.handModel = "aliHand"
t.upperLegModel = "aliUpperLeg"
t.lowerLegModel = "agentLowerLeg"
t.toesModel = "aliToes"

t.jumpSounds=["spazJump01",
              "spazJump02",
              "spazJump03",
              "spazJump04"]
t.attackSounds=["agentAttack01",
                "agentAttack02",
                "agentAttack03",
                "agentAttack04"]
t.impactSounds=["pixieImpact01",
                "pixieImpact02",
                "pixieImpact03",
                "pixielmpact04"]
t.deathSounds=["shatter"]
t.pickupSounds=["shatter"]
t.fallSounds=["powerdown01"]

t.style = 'agent'