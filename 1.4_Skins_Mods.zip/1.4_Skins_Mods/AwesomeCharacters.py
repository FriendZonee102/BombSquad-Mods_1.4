# coding=utf-8
from bsSpaz import *

# Penguin Dude # Created by Friends
t = Appearance("Penguin Dude")
t.colorTexture = "penguinColor"
t.colorMaskTexture = "egg2"
t.iconTexture = "eggTex1"
t.iconMaskTexture = "eggTex1"

t.headModel = "neoSpazHead"
t.torsoModel = "penguinTorso"
t.pelvisModel = "agentPelvis"
t.upperArmModel = "penguinUpperArm"
t.foreArmModel = "penguinForeArm"
t.handModel = "neoSpazHand"
t.upperLegModel = "penguinUpperLeg"
t.lowerLegModel = "penguinLowerLeg"
t.toesModel = "neoSpazToes"

t.jumpSounds=["penguinJump01",
              "penguinJump02",
              "penguinJump03",
              "penguinJump04"]
t.attackSounds=["penguinAttack01",
                "penguinAttack02",
                "penguinAttack03",
                "penguinAttack04"]
t.impactSounds=["pixieImpact01",
                "pixieImpact02",
                "pixieImpact03",
                "pixielmpact04"]
t.deathSounds=["cyborgDeath01"]
t.pickupSounds=["cyborgPickup01"]
t.fallSounds=["cyborgFall01"]

t.style = 'pixie'

# Weird Man # Created by Friends
t = Appearance("Weird Man")
t.colorTexture = "powerupHealth"
t.colorMaskTexture = "powerupHealth"
t.iconTexture = "neoSpazIcon"
t.iconMaskTexture = "cuteSpaz"

t.headModel = "landMine"
t.torsoModel = "bunnyTorso"
t.pelvisModel = "pixiePelvis"
t.upperArmModel = "wing"
t.foreArmModel = "wing"
t.handModel = "aliHand"
t.upperLegModel = "cyborgUpperLeg"
t.lowerLegModel = "cyborgLowerLeg"
t.toesModel = "aliToes"

t.jumpSounds=["spazJump01",
              "spazJump02",
              "spazJump03",
              "spazJump04"]
t.attackSounds=["agentAttack01",
                "agentAttack02",
                "agentAttack03",
                "agentAttack04"]
t.impactSounds=["pixieImpact01",
                "pixieImpact02",
                "pixieImpact03",
                "pixielmpact04"]
t.deathSounds=["shatter"]
t.pickupSounds=["shatter"]
t.fallSounds=["powerdown01"]

t.style = 'female'