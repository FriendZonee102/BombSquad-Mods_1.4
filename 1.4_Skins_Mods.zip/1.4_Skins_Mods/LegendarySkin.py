# coding=utf-8
from bsSpaz import *


###############  SPAZ   ##################
t = Appearance("Legendary")

t.colorTexture = "egg1"
t.colorMaskTexture = "egg1"

t.iconTexture = "aliIcon"
t.iconMaskTexture = "egg3"

t.headModel = "frostyHead"
t.torsoModel = "aliTorso"
t.pelvisModel = "aliPelvis"
t.upperArmModel = "bunnyPelvis"
t.foreArmModel = "bunnyPelvis"
t.handModel = "bunnyPelvis"
t.upperLegModel = "aliUpperLeg"
t.lowerLegModel = "aliLowerLeg"
t.toesModel = "aliToes"

t.jumpSounds=["frostyJump01",
              "frostyJump02",
              "frostyJump03",
              "frostyJump04"]
t.attackSounds=["frostyAttack01",
                "frostyAttack02",
                "frostyAttack03",
                "frostyAttack04"]
t.impactSounds=["aliImpact01",
                "aliImpact02",
                "aliImpact03",
                "aliImpact04"]
t.deathSounds=["frostyDeath01"]
t.pickupSounds=["aliPickup01"]
t.fallSounds=["pixieFall01"]

t.style = 'zoe'